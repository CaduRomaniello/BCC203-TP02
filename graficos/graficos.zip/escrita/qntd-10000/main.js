var trace1 = {
    x: ["QuickSort", "Substituição por seleção", "Vários Caminhos"],
    y: [10000,
      10000,
      40000],
    name: 'Crescente',
    marker: {color: 'rgb(8, 126, 139)'},
    type: 'bar'
  };
  
  var trace2 = {
    x: ["QuickSort", "Substituição por seleção", "Vários Caminhos"],
    y: [10000,
      30087,
      40000],
    name: 'Decrescente',
    marker: {color: 'rgb(255, 90, 95)'},
    type: 'bar'
  };

  var trace3 = {
    x: ["QuickSort", "Substituição por seleção", "Vários Caminhos"],
    y: [70122,
      30251,
      40000],
    name: 'Desordenado',
    marker: {color: 'rgb(60, 60, 60)'},
    type: 'bar'
  };
  
  var data = [trace1, trace2, trace3];
  
  var layout = {
    title: 'Escrita no arquivo',
    xaxis: {tickfont: {
        size: 14,
        color: 'rgb(107, 107, 107)'
      }},
    yaxis: {
      title: 'Acessos',
      titlefont: {
        size: 16,
        color: 'rgb(107, 107, 107)'
      },
      tickfont: {
        size: 14,
        color: 'rgb(107, 107, 107)'
      }
    },
    legend: {
      x: 1.0,
      y: 1.0,
      bgcolor: 'rgba(255, 255, 255, 0)',
      bordercolor: 'rgba(255, 255, 255, 0)'
    },
    barmode: 'group',
    bargap: 0.15,
    bargroupgap: 0.1
  };
  
  Plotly.newPlot('myDiv', data, layout);